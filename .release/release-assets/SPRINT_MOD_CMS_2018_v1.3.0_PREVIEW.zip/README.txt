SPRINT MOD CMS 2018 - v1.3.0

INSTALL
Requires Car Mechanic Simulator 2018 (Windows) with BepInEx 5 installed.
Built against BepInEx 5.4.23.5, Harmony 2.9.0 and Unity 2017.4.24.
Dependencies and game assemblies are not included.
1. Close the game. Back up any existing SPRINT MOD CMS 2018.dll outside BepInEx/plugins.
2. Copy the included BepInEx folder into the game folder, merging the folders.
   The only installed file is BepInEx/plugins/SPRINT MOD CMS 2018.dll.
3. Start the game and open Escape > Sprint Mod Settings.
Install only ONE sprint mod DLL. Do not install older versions alongside it.

CONTROLS AND SETTINGS
Default: hold either Shift key; 150% speed; crouched sprint off.
Sprint Mod Settings sits immediately above Continue, with Continue last.
The settings submenu uses native game buttons and text styling.
Click the speed field, type an integer, then press Enter or click away to apply.
Values are clamped to 100-250%; empty/invalid input keeps the previous setting.
Other settings: sprint on/off, keyboard binding, hold/toggle, crouched sprint, reset.
Escape cancels key rebinding or returns from the submenu. Back also returns.
Configuration: BepInEx/config/cms2018.sprint.standalone.cfg.

FOOTSTEP AUDIO (NEW IN 1.3.0)
While sprinting, vanilla footstep playback scales with the active movement multiplier:
150% = 1.5x playback; 200% = 2x; 250% = 2.5x.
Playback speed also changes pitch. The game clips are retained.
The patch adjusts the native high-velocity cutoff for sprint movement.

BUILD FROM SOURCE
Source/ contains the complete v1.3.0 C# source and Build.ps1.
From that directory, run Build.ps1 with PowerShell on Windows.
For a custom install location: .\Build.ps1 -GamePath 'D:\SteamLibrary\steamapps\common\Car Mechanic Simulator 2018'
The script references DLLs in your own game and BepInEx installation, and creates
SPRINT MOD CMS 2018.dll next to the source. It does not install it automatically.
Build uses the game's CLR 2 libraries rather than Windows' default .NET libraries.

UNINSTALL
Close the game and remove only BepInEx/plugins/SPRINT MOD CMS 2018.dll.
The mod does not write save-game data. Configuration may be retained for reinstalling.

VALIDATION / RELEASE STATUS
v1.3.0: compilation, CLR references, expected audio patch layout and installed DLL
SHA-256 were checked. The user confirmed the native menu in v1.1.0 works.
v1.2.0 numeric input and v1.3.0 audio changes have not been verified live in-game.
Treat v1.3.0 as a preview until menu, typing, key binding, hold/toggle, crouching,
footsteps at 100/150/200/250%, scene changes and coexistence with other mods are tested.
The external Harmony runtime dry-run could not complete in the test host.
Report game version, mod version and relevant BepInEx/LogOutput.log errors with issues.
